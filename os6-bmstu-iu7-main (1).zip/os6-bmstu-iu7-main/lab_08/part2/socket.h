#ifndef _SOCKET_H_

#define _SOCKET_H_

#define PORT 9877

#define MAX_LEN_BUF 64

#define TRUE 1
#define FALSE 0

#endif